<?php
define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_NAME', 'mabumbat_mabumbatech');
define('DB_USER', 'mabumbat_mabumba');
define('DB_PASS', 'PUT_YOUR_DATABASE_PASSWORD_HERE');
define('APP_BASE_URL', '');
